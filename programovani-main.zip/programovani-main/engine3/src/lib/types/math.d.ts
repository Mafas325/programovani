declare function clamp(x: number, min: number, max: number): number;
