

// Doplňte funkci drawLine, aby nakreslila čáru mezi dvěma body
// proměnné pointA a pointB jsou vektory
// Užitečné funkce:
//      - line(x1, y1, x2, y2) - nakreslí čáru mezi body (x1, y1) a (x2, y2)
//      - vector.x - x-ová složka vektoru
//      - vector.y - y-ová složka vektoru
function drawLine(pointA, pointB) {
       line (pointA.x, pointA.y, pointB.x, pointB.y)
}