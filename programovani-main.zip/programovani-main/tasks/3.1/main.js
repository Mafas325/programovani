
// Doplňte třídu Rigidbody, tak aby šlo vytvořit nové Rigidbody na pozici (x, y)
// jako 'new Rigidbody(x, y)', tedy kdybychom chtěli vytvořit nové Rigidbody
// na pozici (100, 200), tak můžeme napsat 'new Rigidbody(100, 200)'

// Po vytvoření nového Rigidbody je potřeba uložit jeho pozici do vektoru 'pos' resp. 'this.pos'

// Užitečné funkce:
//      constructor(parametry...) { tělo... }
//      createVector(x, y)

class Rigidbody {
    constructor(x, y) {
    this.pos = createVector(x, y);
}
}